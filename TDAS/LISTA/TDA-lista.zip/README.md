#Algo2 - TDA lista - 2°cuatrimestre 2020 - Franco Leonardo Acciardi 106272



	Resumen:
		El trabajo entregado es la implementacion del Tipo de dato abstracto lista. Ademas del TDA principal de lista tambien se implmentarojn los TDA pila y cola junto con iteradores interno y externo para la lista.
		A su vez tambien se crearon y corrieron una serie de pruebas sobre todos los TDAs. Las mismas se hicieron utilizando el archivo pa2mm.h brindado por la catedra y estan disponibles en pruebas.c . 


	Compilacion:
		Comando)	gcc -g -std=c99 -Wall -Wconversion -Wtype-limits -pedantic -Werror -O0 lista.c pruebas.c -o lista_se
		Makefile)	make compilar	


	Ejecucion:
		Comando)	valgrind --leak-check=full --track-origins=yes --show-reachable=yes ./lista_se
		Makefile)	make valgrind


	Composicion del TP:
		El TP consta de 2 archivos .c y 2 archivo .h
			-En lista.c esta la implementacion de las funciones cuyas firmas fueron dadas en lista.h.
			-En pruebas.c se encuentra el main del programa y es donde se corren las distintas pruebas que verfifican el correcto funcionamiento del TDA.
		#El usuario final no debiera tener acceso a los .c y solo podria ver las primitivas a su disposicion en el .h sin conocer como estan implementadas las mismas.





	Funcionamiento de pruebas.c:

		+)Las pruebas se encuentran agrupadas en categorias segun lo que prueban.

		+)Dentro de los grupos hay otros subgrupos que se encargan de agrupar las pruebas sobre un elemento y hacer el seguimineto de las pruebas mas sencillo.

		+)Se prueba tanto el correcto funcionamiento de la lista como de la cola y la pila. Tambien se realizan pruebas sobre los iteradores tanto interno como externo.

		+)Cada subgrupo de pruebas funciona de manera independiente, por lo que pueden quitarse y agregarse grupos de pruebas sin afectar al resto. 

		+)Para la implemantacion de las pruebas se utiliza el archivo pa2mm.h el cual permite mostrar por pantalla si una prueba tuvo exito o no.
			-)A la funcion pam_afirmar se le pasan 2 parametros:
				1)Una condicion a ser evaludada como verdadera o falsa, la cual determina si el resultado de la prueba es el esperado o no.
				2)Una linea de texto que es la que sera impresa por pantalla junto con una tilde verde en caso de que la condicion pasada sea verdadera (se paso la     
					prueba correctamente) o una cruz roja en caso de que sea falsa (no se completo la prueba correctamente).






	Comentarios sobre la implemantacion de las funciones de lista.h:

		+) A la hora de determinar si una lista pasada es verdadera o falsa se analizan todos los casos posibles en las que la lista pueda venir 'rota', esto es:
			-)Que tenga el nodo inicial o final nulo y el otro no.
			-)Que tenga ambos nodos nulos cuando diga tener elementos guardados.
			-)Que alguno de los nodos (inicial o final) sea  no nulo cuando diga no tener ningun elñemento guardado. 

		+)El iterador externo solo dira que no puede seguir iterando cuando halla pasado al ultimo elemento de la lista y este apuntando a NULL, esto implica que la
			funcion 'iterador_tiene_siguiente' solo devolvera false una vez iterada completamente toda la lista (incluido el ultimo nodo) y se halla salido de la lista.

		+)La funcion 'lista_destruir' solo se hará responsable de detruir aquellas lista creadas y modificadas con las primitivas provistas, lo cual garantiza su
			validez. En caso de modificar la lista  manualmente accediendo a la estructura y haciendola inválida esta funicon no destruira dicha lista.

		+) 'lista_vacia' devolverá true solo cuando la lista este vacia (tenga 0 elementos) y ademas dicha lista vacia sea valida (tenga nodos inicial y final nulos). En caso de ser una lista inválida devolverá false como si estuviese llena pese a que la cantidad sea 0.

		+) Las funciones de pila y cola estan implementadas como casos particulares de lista.

		+)El iterador interno no iterará los lementos de la lista si no se le pas auna funcion que haga algo con ellos, pues no tiene sentido simplemente reccorer los lementos hasta el final de la lista sin hacer nada con ellos.




--------------------------------------------------------------------------------------------------------------------------------------------------------------





1)	

	Una lista es un arreglo de elementos en el cual se puede acceder, borrar o instertar un elemento en cualquier posicion. La forma mas tipica (y la empleada en este
	 caso) para implementarla es con Nodos enlazados. Estos nodos enlazados contienen el elemento de la lista en si y al menos una referencia al nodo que le sucede en la lista. (+El nodo es un tipo de dato abstracto que se caracteriza por contener informacion y tener al menos una referencia a otro nodo). 

	En los casos en los que cada nodo solo tiene una referencia al nodo que le sigue en la lista, se dice que la lista es simplemente enlazada. Si en cambio, cada nodo tiene una referencia al nodo que le precede y al que lo sucede, se trata de una lista doblemente enlazada (cada nodo tiene una referencia al enterior y al 
	siguiente). En esta ocasion se implementó una lista simplemente enlazada.

	La lista (En este caso simplemente enlazada) termina cuando se alcanza al nodo final, este es aquel que tiene la referencia al siguiente nodo Nula.

	En una lista simplemente enlazada solo se pueden recorrer los elementos en una direccion, ya que solo hay una referencia en cada nodo. No hay forma de volver para atras en la,iteracion de los elementos.

	En una lista doblemente enlazada pueden recorrerse los elementos en 2 direcciones ya que cada nodo conoce a su sucesor y a su predecesor. Esto permite recorrer la lista de principio a fin y de fin a principio, asi como 'volver atras' en la iteracion. Si además se enlaza el nodo final de la lista al primero nos encontramos frente a una lista circular.


2)	
	
	Características de la pila:
		+)La posicion en el extremo final es denominada tope.
		+)La insercion en el ultimo lugar recibe el nombre de apilado
		+)La eliminacion en el ultimo lugar recibe el nombre de desapilado
		+)Solo puede accederse (para obtener el elemento, borrarlo o insertar uno nuevo) al tope.
		+)Podemos hacer una analogia entre este TDA y una pila de platos para lavar.

	Caracteristicas de la cola:
		+)La posicion en el extremo inicial se denomina frente.
		+)La posicion en el extremo final se denomina final.
		+)Solo pueden insertarse elementos al final de la cola, el procedimiento recibe el nombre de encolado.
		+)Solo pueden eliminarse elementos al frente de la cola, el procedimiento recibe el nombre de desencolado.
		+)Podemos hacer una analogia entre este TDA y una fila para entrar a un restaurante.

3)

	El iterador es una estructura que nos permite recorrer secuencialmente (iterar) los elementos de un TDA (pila, cola, lista, arbol, atc) sin conocer la implementacion o estructura interna del mismo.

	El iterador puede ser interno o externo, y entre las operaciones que puden realizarse con él se encuentran (ademas de las basicas como crearlo y destruirlo):
		+)Primero: Esta operacion permite que el iterador apunte al primer elemento de la estructura sobre el que este iterando, en este caso al primer nodo de la 
					lista.

		+)hay_mas: Permite determinar si el iterador puede seguir iterando o no. No podrá hacerlo en caso de haber llegado al final de la estructura.

		+)siguiente: Permite al iterador pasar a apuntar al siguiente elemento en la estructura.

		+)Elemento_actual: Permite acceder al contenido del elemento de la estructura al que se esta apuntando.

4)
	
	Diferencias entre iterador interno y externo:

	+)Iterador interno:
		-)Su implementacion esta incluida dentro del mismo TDA que itera.
		-)Maneja la iteracion dentro de la estructura que se esta iterando.
		-)El usuario de la estructura/TDA no pueda controlar la iteracion manualmente.
		-)Normalmente recibe 3 parametros para poder realizar su iteracion:
			-->	La estructructura sobre la cual va a iterar.
			-->	Un puntero a una funcion, la cual será aplicada sobre cada lemento de la estructura iterado. Esta funcion a su vez recibe como parametros el contenido 
				dentro del elementos de la estructura (en nuestro caso el puntero al elemento dentro del nodo) y un puntero adicional como contexto para saber que hacer o cuando detenerse.
			--> Un puntero adicional por si la funcion lo necesita (Como por ejemplo un contador para saber cuando detenerse).

	+)Iterador externo:
		-)Su implementacion esta en un TDA aparte del que itera.
		-)Maneja la iteracion fuera de la estructura que se esta iterando y posee sus propias operaciones primitivas separadas.
		-)El usuario de la puede controlar la iteracion manualmente por medio de las primitivas.
		



	La principal diferencioa entre un iterador interno y uno externo es que el primero maneja la iteracion dentro de la estructura que se esta iterando, lo que implica que el usuario de la estructura/TDA no pueda controlar la iteracion manualmente.

